﻿namespace SmsPanel.Models;

public enum PanelType
{
    GapYar,
    Amoot
}

public class Panel
{
    public string Type { get; set; }
}
