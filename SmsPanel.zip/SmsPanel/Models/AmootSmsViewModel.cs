﻿namespace SmsPanel.Models;

public class AmootSmsViewModel
{
    public const string AmootSms = "AmootSms";
    public string UserName { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string SmsNumber { get; set; } = string.Empty;
}
