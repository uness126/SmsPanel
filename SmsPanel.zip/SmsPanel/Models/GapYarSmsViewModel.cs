﻿namespace SmsPanel.Models;

public class GapYarSmsViewModel
{
    public const string GapYarSms = "GapYarSms";
    public string UserName { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string SmsNumber { get; set; } = string.Empty;
}
